//
//  Model.swift
//  CoreDataPlayground
//
//  Created by gietal on 9/29/18.
//  Copyright © 2018 gietal. All rights reserved.
//

import Foundation
import AppKit


struct DataModel {
    var id: String
    var image: NSImage
}
